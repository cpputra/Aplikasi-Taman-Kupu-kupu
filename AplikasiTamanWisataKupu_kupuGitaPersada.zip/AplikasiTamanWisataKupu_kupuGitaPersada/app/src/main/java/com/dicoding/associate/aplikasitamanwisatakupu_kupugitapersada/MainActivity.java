package com.dicoding.associate.aplikasitamanwisatakupu_kupugitapersada;

import android.app.Activity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends Activity {

    //CardView btnstart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Thread thread = new Thread(){
            public void run(){
                try{
                    sleep(5000);
                }catch (InterruptedException e){
                    e.printStackTrace();
                }finally{
                    startActivity(new Intent(MainActivity.this,MenuActivity.class));
                    finish();
                }
            }
        };
        thread.start();

        /*btnstart = (CardView) findViewById(R.id.btn_start);
        btnstart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMenu();
                Toast.makeText(getApplicationContext(), "Memulai Aplikasi", Toast.LENGTH_LONG).show();
            }
        });
    }
    public void openMenu(){
        Intent intent = new Intent(this, MenuActivity.class);
        startActivity(intent);*/
    }

}
