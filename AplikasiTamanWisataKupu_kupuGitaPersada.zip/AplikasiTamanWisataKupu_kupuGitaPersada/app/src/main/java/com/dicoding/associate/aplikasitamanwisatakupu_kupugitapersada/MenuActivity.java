package com.dicoding.associate.aplikasitamanwisatakupu_kupugitapersada;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

public class MenuActivity extends AppCompatActivity implements View.OnClickListener {

    ImageButton info_umum, koleksi, tentang_kami, website, fasilitas, lokasi;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        info_umum = (ImageButton) findViewById(R.id.info_umum);
        info_umum.setOnClickListener(this);

        koleksi = (ImageButton) findViewById(R.id.koleksi);
        koleksi.setOnClickListener(this);

        fasilitas = (ImageButton) findViewById(R.id.fasilitas);
        fasilitas.setOnClickListener(this);

        lokasi = (ImageButton) findViewById(R.id.lokasi);
        lokasi.setOnClickListener(this);

        tentang_kami = (ImageButton) findViewById(R.id.tentang_kami);
        tentang_kami.setOnClickListener(this);

        website = (ImageButton) findViewById(R.id.website);
        website.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
            switch (v.getId()) {
                case R.id.info_umum:
                    Intent infoIntent = new Intent(MenuActivity.this, InformasiUmumActivity.class);
                    startActivity(infoIntent);
                    Toast.makeText(getApplicationContext(), "Membuka Informasi Umum", Toast.LENGTH_LONG).show();
                    break;

                case R.id.koleksi:
                    Intent koleksiIntent = new Intent(MenuActivity.this, KoleksiActivity.class);
                    startActivity(koleksiIntent);
                    Toast.makeText(getApplicationContext(), "Membuka Koleksi", Toast.LENGTH_LONG).show();
                    break;

                case R.id.fasilitas:
                    Intent fasilitasIntent = new Intent(MenuActivity.this, FasilitasActivity.class);
                    startActivity(fasilitasIntent);
                    Toast.makeText(getApplicationContext(), "Membuka Fasilitas", Toast.LENGTH_LONG).show();
                    break;

                case R.id.lokasi:
                    Intent lokasiIntent = new Intent(MenuActivity.this, MapsActivity.class);
                    startActivity(lokasiIntent);
                    Toast.makeText(getApplicationContext(), "Membuka Lokasi", Toast.LENGTH_LONG).show();
                    break;

                case R.id.tentang_kami:
                    Intent tentangIntent = new Intent(MenuActivity.this, TentangKamiActivity.class);
                    startActivity(tentangIntent);
                    Toast.makeText(getApplicationContext(), "Membuka Tentang Kami", Toast.LENGTH_LONG).show();
                    break;

                case R.id.website:
                    Intent webIntent = new Intent(MenuActivity.this, WebsiteActivity.class);
                    startActivity(webIntent);
                    Toast.makeText(getApplicationContext(), "Membuka Website", Toast.LENGTH_LONG).show();
                    break;
            }
    }
}
