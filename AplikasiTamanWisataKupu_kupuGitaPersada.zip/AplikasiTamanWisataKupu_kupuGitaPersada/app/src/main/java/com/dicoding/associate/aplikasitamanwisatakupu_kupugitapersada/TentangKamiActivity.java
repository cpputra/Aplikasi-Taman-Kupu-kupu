package com.dicoding.associate.aplikasitamanwisatakupu_kupugitapersada;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class TentangKamiActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tentang_kami);
    }
}
