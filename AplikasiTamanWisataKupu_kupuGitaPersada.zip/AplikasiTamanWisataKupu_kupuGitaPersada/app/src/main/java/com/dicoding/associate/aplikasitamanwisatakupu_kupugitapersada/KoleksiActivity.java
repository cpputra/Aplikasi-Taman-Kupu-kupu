package com.dicoding.associate.aplikasitamanwisatakupu_kupugitapersada;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.view.View;
import android.widget.Toast;

public class KoleksiActivity extends AppCompatActivity {

    CardView jenis1, jenis2, jenis3, jenis4, jenis5, jenis6, jenis7;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_koleksi);

        jenis1 = (CardView) findViewById(R.id.jenis1);
        jenis1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openPapilonidae();
                Toast.makeText(getApplicationContext(), "Memilih Papilonidae", Toast.LENGTH_LONG).show();
            }
        });
        jenis2 = (CardView) findViewById(R.id.jenis2);
        jenis2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openNymphalidae();
                Toast.makeText(getApplicationContext(), "Memilih Nymphalidae", Toast.LENGTH_LONG).show();
            }
        });
        jenis3 = (CardView) findViewById(R.id.jenis3);
        jenis3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openPieridae();
                Toast.makeText(getApplicationContext(), "Memilih Pieridae", Toast.LENGTH_LONG).show();
            }
        });
        jenis4 = (CardView) findViewById(R.id.jenis4);
        jenis4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openLycaenidae();
                Toast.makeText(getApplicationContext(), "Memilih Lycaenidae", Toast.LENGTH_LONG).show();
            }
        });
        jenis5 = (CardView) findViewById(R.id.jenis5);
        jenis5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openRiodinidae();
                Toast.makeText(getApplicationContext(), "Memilih Riodinidae", Toast.LENGTH_LONG).show();
            }
        });
        jenis6 = (CardView) findViewById(R.id.jenis6);
        jenis6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openHesperiidae();
                Toast.makeText(getApplicationContext(), "Memilih Hesperiidae", Toast.LENGTH_LONG).show();
            }
        });
        jenis7 = (CardView) findViewById(R.id.jenis7);
        jenis7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMoth();
                Toast.makeText(getApplicationContext(), "Memilih Moth", Toast.LENGTH_LONG).show();
            }
        });
    }


    public void openPapilonidae(){
        Intent intent1 = new Intent(this, ListActivity.class);
        startActivity(intent1);
    }
    public void openNymphalidae(){
        Intent intent2 = new Intent(this, ListActivity.class);
        startActivity(intent2);
    }
    public void openPieridae(){
        Intent intent3 = new Intent(this, ListActivity.class);
        startActivity(intent3);
    }
    public void openLycaenidae(){
        Intent intent4 = new Intent(this, ListActivity.class);
        startActivity(intent4);
    }
    public void openRiodinidae(){
        Intent intent5 = new Intent(this, ListActivity.class);
        startActivity(intent5);
    }
    public void openHesperiidae(){
        Intent intent6 = new Intent(this, ListActivity.class);
        startActivity(intent6);
    }
    public void openMoth(){
        Intent intent7 = new Intent(this, ListActivity.class);
        startActivity(intent7);
    }


}
